function Home() {
	return (
		<div className="router-page-home-container">
			<h1>Welcome to Vibe Check!</h1>
		</div>
	);
}

export default Home;
