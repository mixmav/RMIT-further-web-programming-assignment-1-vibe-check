import { useRef } from 'react';
import { useAuth, useAuthUpdate } from 'Context/AuthContext';
import { useUserDatastore } from 'Context/UserDatastoreContext';

function EditProfileDialog(props){
	const containerRef = useRef();
	const auth = useAuth();
	const userDatastore = useUserDatastore();

	const handleClick = (event) => {
		props.toggleVisible(false);
	}

	const checkClickClose = (event) => {
		if (event.target === containerRef.current && containerRef.current.contains(event.target)) {
			props.toggleVisible(false);
		}
	}

	return (
		<div className="router-page-profile--component-edit-profile-dialog" onClick={checkClickClose} ref={containerRef}>
			<div className="dialog">
				<button className="btn" onClick={handleClick}><i className="fa fa-window-close"></i>Close</button>
			</div>
		</div>
	);
}

export default EditProfileDialog;